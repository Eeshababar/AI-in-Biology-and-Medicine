TOKENS = ['A', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'Y']
NUM_TOKENS = len(TOKENS)
BATCH_SIZE = 16
NUM_EPOCHS = 8
LEARNING_RATE = 0.001
MAX_LEN = 1024